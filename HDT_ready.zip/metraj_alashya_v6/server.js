const express = require("express");
const multer = require("multer");
const rateLimit = require("express-rate-limit");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";
const MAX_FILE_SIZE = 8 * 1024 * 1024;
const allowed = new Set(["image/jpeg", "image/png", "image/webp"]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE, files: 1 }
});

const analyzeLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "تم الوصول إلى حد الطلبات مؤقتًا. حاول بعد دقيقة." }
});

app.disable("x-powered-by");
app.use(express.static(__dirname));

app.get("/health", (req, res) => {
  res.json({ ok: true, service: "HDT", model: MODEL });
});

const resultSchema = {
  type: "object",
  properties: {
    name: { type: "string" },
    description: { type: "string" },
    use: { type: "string" },
    notes: { type: "string" },
    confidence: { type: "string", enum: ["مرتفع", "متوسط", "منخفض"] },
    possible_matches: { type: "array", items: { type: "string" } }
  },
  required: ["name", "description", "use", "notes", "confidence", "possible_matches"],
  additionalProperties: false
};

app.post("/analyze", analyzeLimiter, upload.single("image"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "مفتاح الذكاء الاصطناعي غير مضبوط على الخادم." });
    }
    if (!req.file) return res.status(400).json({ error: "لم يتم اختيار صورة." });
    if (!allowed.has(req.file.mimetype)) {
      return res.status(400).json({ error: "نوع الصورة غير مدعوم. استعمل JPG أو PNG أو WEBP." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const b64 = req.file.buffer.toString("base64");

    const response = await client.responses.create({
      model: MODEL,
      input: [{
        role: "user",
        content: [
          {
            type: "input_text",
            text: [
              "أنت مساعد للتعرّف على الأشياء من الصور.",
              "حلّل الصورة بالعربية وأرجع JSON فقط وفق المخطط المحدد.",
              "name: اسم الشيء أو أقرب وصف معروف.",
              "description: وصف قصير لما يظهر في الصورة.",
              "use: الاستعمال المحتمل إذا كان واضحًا.",
              "notes: درجة عدم اليقين وأي ملاحظة مفيدة.",
              "confidence: مرتفع أو متوسط أو منخفض حسب وضوح التعرف.",
              "possible_matches: أسماء بديلة محتملة فقط إذا كان التعرف غير مؤكد، وإلا قائمة فارغة.",
              "إذا لم تكن الهوية واضحة، لا تخمّن بثقة؛ اذكر أن التعرف غير مؤكد.",
              "لا تعطِ تعليمات لتنفيذ أعمال خطرة."
            ].join("\n")
          },
          {
            type: "input_image",
            image_url: `data:${req.file.mimetype};base64,${b64}`,
            detail: "auto"
          }
        ]
      }],
      text: {
        format: {
          type: "json_schema",
          name: "object_identification",
          strict: true,
          schema: resultSchema
        }
      }
    });

    let data;
    try {
      data = JSON.parse(response.output_text);
    } catch {
      return res.status(502).json({ error: "وصلت نتيجة غير منظمة من نموذج التحليل." });
    }
    res.json(data);
  } catch (err) {
    console.error(err);
    const status = err?.status === 429 ? 429 : 500;
    res.status(status).json({
      error: status === 429
        ? "الخدمة مشغولة أو تم تجاوز حد الاستخدام. حاول لاحقًا."
        : "تعذر تحليل الصورة. تحقق من إعدادات الخادم ومفتاح API."
    });
  }
});

app.use((err, req, res, next) => {
  if (err?.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "الصورة أكبر من 8MB." });
  }
  console.error(err);
  res.status(500).json({ error: "حدث خطأ غير متوقع." });
});

app.listen(PORT, () => console.log(`HDT listening on port ${PORT}`));
